export default [
	{ value: 'arial', name: 'Arial' },
	{ value: 'arial_black', name: 'Arial Black' },
	{ value: 'avenir_roman', name: 'Avenir Roman' },
	{ value: 'futura_bold', name: 'Futura Bold' },
]
