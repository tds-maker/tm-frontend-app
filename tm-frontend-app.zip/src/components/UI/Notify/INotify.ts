export default interface INotify {
	id: number
	title: string
	message: string
	color: string
}
