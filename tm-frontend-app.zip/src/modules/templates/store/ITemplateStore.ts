import IEditTemplateStore from '../routes/EditTemplate/ducks/interfaces'

export default interface ITemplateStore {
	editTemplate: IEditTemplateStore
}
