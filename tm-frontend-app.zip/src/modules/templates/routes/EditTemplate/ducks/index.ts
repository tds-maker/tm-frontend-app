import reducer from './reducers'

export { default as editTemplateSelectors } from './selectors'
export { default as editTemplateOperations } from './operations'
export { default as editTemplateTypes } from './types'

export default reducer
