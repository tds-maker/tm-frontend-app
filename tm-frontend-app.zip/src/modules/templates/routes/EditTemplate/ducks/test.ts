import actions from './actions';
import { IElement } from './interfaces';
import { metaDomType, metaType } from './enums';
import types from './types';

// import '../../../../../utils/string.prototypes'

describe('Edit template tests', () => {
	describe('Actions', () => {
		it('Set element style action', () => {
			const fakeElement:IElement = {
				_id : "fake-id",
				_meta: {
					typeName: metaType.text,
					htmlDom: metaDomType.div
				},
				elements: [],
				style: {
					width: "10px"
				}
			}
			
			expect(actions.setElementStyle(fakeElement, { width: "20px" }, 'options')).toEqual({
				type: types.SET_ELEMENT_STYLE,
				payload : {
					element: fakeElement,
					style: { width: "20px",
					options: 'options'
				}
			})
		})
	})
})
