import * as React from 'react'
import './main-left-side.style.scss'

const MainLeftSide = () => {
	return <div className="main-left-side" />
}

export default MainLeftSide
