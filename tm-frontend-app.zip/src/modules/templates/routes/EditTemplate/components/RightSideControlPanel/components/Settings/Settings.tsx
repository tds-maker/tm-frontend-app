import * as React from 'react'
import PageSettings from './PageSettings'
import './settings.style.scss'
const Settings = () => (
	<div className="setting-tab-inner">
		<PageSettings />
	</div>
)

export default Settings
