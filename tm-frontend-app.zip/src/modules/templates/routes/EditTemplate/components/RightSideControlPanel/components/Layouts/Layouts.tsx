import * as React from 'react';
import LayoutSelect from './LayoutSelect';

import './layouts.style.scss';
const Layouts = () => (
	<div className="setting-tab-inner">
		<LayoutSelect />
	</div>
)

export default Layouts