import HeaderGroup from './HeaderGroup'
// import IStore from '../../../../../../../../store/IStore';
// import {editTemplateOperations, editTemplateSelectors} from '../../../../ducks';

// const mapStateToProps = (state: IStore) => ({
//     header: editTemplateSelectors.activeHeader(state),
// })

// const mapDispatchToProps = (dispatch:any) => ({
//     enableDisableHeader: (isEnabled: boolean) => dispatch(editTemplateOperations.changeHeaderStatus(isEnabled))
// })

export default HeaderGroup
