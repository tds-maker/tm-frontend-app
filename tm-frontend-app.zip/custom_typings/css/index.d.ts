declare module '*.css' {
	const value: any
	export default value
}
